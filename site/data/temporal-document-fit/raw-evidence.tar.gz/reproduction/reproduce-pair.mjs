// Independent invocation of frozen implementation; one paired c10 cell, not new benchmark repetitions.
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
import {join,resolve} from 'node:path';
import {readFile,writeFile,mkdir,appendFile} from 'node:fs/promises';
import {openSync,closeSync} from 'node:fs';
import {fork} from 'node:child_process';
import {createHash} from 'node:crypto';
const source=resolve(process.env.TDF_SOURCE),root=resolve(process.env.TDF_RUNTIME_ROOT),original=resolve(process.env.TDF_ORIGINAL_RUN);
assert(process.argv.includes('--execute-authorized'),'Prepare only unless explicitly authorized');
const require=createRequire(join(source,'package.json'));
const {Connection,Client,WorkflowIdReusePolicy}=require('@temporalio/client');
const {fixtures,workload,digest,SEED}=await import(pathToFileURL(join(source,'fixtures.mjs')));
const {verifyTimingRows}=await import(pathToFileURL(join(source,'suites.mjs')));
const {OwnedRuntime,until}=await import(pathToFileURL(join(source,'runtime.mjs')));
const originalManifest=JSON.parse(await readFile(join(original,'manifest.json'),'utf8'));
const originalReport=JSON.parse(await readFile(join(original,'report.json'),'utf8'));
assert.equal(originalReport.outcome,'mechanisms-supported','Original run must have finished successfully');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
async function verifyHashes(){for(const [file,hash]of Object.entries(originalManifest.sources))assert.equal(sha(await readFile(join(source,file.split('/').at(-1)))),hash,`Frozen source mismatch: ${file}`);}
await verifyHashes();
const runtime=await new OwnedRuntime(root).load();
const id=`reproduce-${new Date().toISOString().replace(/[:.]/g,'-')}`,out=join(root,'reproduction',id),queue=id;
await mkdir(out,{recursive:true});
const save=(name,data)=>writeFile(join(out,name),JSON.stringify(data,null,2)+'\n');
const report={id,originalRun:originalManifest.runId,scope:'independent invocation, one c10 pair; not additional benchmark repetitions',seed:SEED,cells:[],errors:[],outcome:'inconclusive',startedAt:new Date().toISOString()};
let worker,log,connection,client,monitor,budgetError,busy=false,sequence=0;
const started=Date.now();
async function stopWorker(){if(worker&&worker.exitCode===null&&worker.signalCode===null){worker.kill('SIGTERM');try{await until(()=>worker.exitCode!==null||worker.signalCode!==null,15000);}catch{worker.kill('SIGKILL');await until(()=>worker.exitCode!==null||worker.signalCode!==null,5000);}}}
async function invoke(name,input){if(budgetError)throw budgetError;const handle=await client.workflow.start(name,{taskQueue:queue,workflowId:`${id}-${sequence++}`,args:[input],workflowExecutionTimeout:'120 seconds',workflowIdReusePolicy:WorkflowIdReusePolicy.REJECT_DUPLICATE});let timer;try{return await Promise.race([handle.result(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('120 second workflow cap')),120000);})]);}catch(error){await handle.terminate('Reproduction failed').catch(()=>{});throw error;}finally{clearTimeout(timer);}}
const control=(arm,action,extra={})=>invoke('control',{arm,action,...extra});
try{
 await save('manifest.json',{id,originalRun:originalManifest.runId,originalManifestSha256:sha(await readFile(join(original,'manifest.json'))),sourceHashes:originalManifest.sources,runnerSha256:sha(await readFile(new URL(import.meta.url))),fixtureHash:digest(fixtures(SEED)),runtime:await runtime.manifest(),concurrency:10,arms:['postgres','mongodb'],warmup:100,attemptsPerArm:1000,node:process.version});
 connection=await Connection.connect({address:'127.0.0.1:17239'});client=new Client({connection,namespace:'default',identity:'tdf-independent-reproduction'});
 log=openSync(join(out,'worker.log'),'a');worker=fork(join(source,'worker.mjs'),[],{cwd:source,env:{...process.env,TDF_OUTPUT:out,TDF_QUEUE:queue},stdio:['ignore',log,log,'ipc']});
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(new Error('Worker startup timeout')),60000);worker.once('message',m=>{if(m.ready){clearTimeout(timer);resolve();}});worker.once('exit',code=>{clearTimeout(timer);reject(new Error(`Worker exited ${code}`));});});
 monitor=setInterval(async()=>{if(busy)return;busy=true;try{const sample=await runtime.resources([process.pid,worker.pid]);await appendFile(join(out,'resources.jsonl'),JSON.stringify(sample)+'\n');if(sample.rssBytes>4294967296||sample.runtimeDiskBytes>10737418240||Date.now()-started>600000)throw new Error('Reproduction resource cap exceeded');}catch(error){budgetError=error;await stopWorker();}finally{busy=false;}},2000);
 for(const arm of ['postgres','mongodb']){
  await control(arm,'reset',{seed:SEED});await control(arm,'index');const diagnostics=await control(arm,'diagnostics');
  const warmup=await invoke('batch',{arm,label:`${id}-${arm}-warmup`,operations:workload({warmup:true,seed:SEED}),concurrency:10});assert.equal(warmup.length,100);assert(warmup.every(r=>!r.error));
  const operations=workload({seed:SEED}),label=`${id}-${arm}`,cellStarted=Date.now();
  const rows=await invoke('batch',{arm,label,operations,concurrency:10});
  await appendFile(join(out,'operations.jsonl'),rows.map((r,i)=>JSON.stringify({arm,label,operation:operations[i],...r})).join('\n')+'\n');
  assert.equal(rows.length,1000);assert(rows.every(r=>!r.error));const projections=verifyTimingRows(rows,SEED);assert(projections.ok,projections.errors.join('\n'));
  const snapshot=await control(arm,'snapshot',{label,timing:true,seed:SEED});assert(snapshot.oracle.ok,snapshot.oracle.errors.join('\n'));
  report.cells.push({arm,concurrency:10,attempted:rows.length,completed:rows.filter(r=>!r.error).length,elapsedMs:Date.now()-cellStarted,projections,snapshot,diagnostics});await save('progress.json',report);
 }
 await verifyHashes();if(budgetError)throw budgetError;assert.equal(report.cells.reduce((s,c)=>s+c.completed,0),2000);report.outcome='reproduced';
}catch(error){report.errors.push({message:error.message,stack:error.stack});process.exitCode=1;}
finally{clearInterval(monitor);await until(()=>!busy,10000).catch(e=>{budgetError=e;});if(budgetError){report.outcome='inconclusive';report.errors.push({message:budgetError.message});}await stopWorker();if(log!==undefined)closeSync(log);await connection?.close();report.finishedAt=new Date().toISOString();report.elapsedMs=Date.now()-started;await save('report.json',report);console.log(JSON.stringify({out,outcome:report.outcome,cells:report.cells.length}));}
